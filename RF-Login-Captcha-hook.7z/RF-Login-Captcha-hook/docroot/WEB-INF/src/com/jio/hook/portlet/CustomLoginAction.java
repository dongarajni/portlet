package com.jio.hook.portlet;

import com.liferay.portal.kernel.captcha.CaptchaUtil;
import com.liferay.util.bridges.mvc.MVCPortlet;

import java.io.IOException;
import javax.portlet.PortletException;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;


public class CustomLoginAction extends MVCPortlet  {
	
	/** Serve Resource used for getting captcha
	*
	*/
	
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse) throws IOException,
			PortletException {

		try {
			CaptchaUtil.serveImage(resourceRequest, resourceResponse);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	
/*	private void checkCaptcha(PortletRequest request) throws Exception {
		
	
		String enteredCaptchaText = ParamUtil.getString(request, "captchaText");

		PortletSession session = request.getPortletSession();
		String captchaText = getCaptchaValueFromSession(session);
		
		if (Validator.isNull(captchaText)) {
		throw new Exception("Internal Error! Captcha text not found in session");
		}
		if (!StringUtil.equalsIgnoreCase(enteredCaptchaText, captchaText)) {
		throw new Exception("Invalid captcha text. Please reenter.");
		}
		}

		private String getCaptchaValueFromSession(PortletSession session) throws Exception {
			
		Enumeration<String> atNames = session.getAttributeNames();
		while (atNames.hasMoreElements()) {
		String name = atNames.nextElement();
		if (name.contains("CAPTCHA_TEXT")) {
		return (String) session.getAttribute(name);
		}
		}
		return null;
		}*/
		
		
		
	}
	
	
	
	

	/*public void processAction(
            ActionMapping mapping, ActionForm form, PortletConfig portletConfig,
            ActionRequest actionRequest, ActionResponse actionResponse)
           throws Exception {
		
        ThemeDisplay themeDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);

        if (actionRequest.getRemoteUser() != null) {
            actionResponse.sendRedirect(themeDisplay.getPathMain());

            return;
        }

        try {
            PortletPreferences preferences = PortletPreferencesFactoryUtil.getPortletSetup(actionRequest);

            login(themeDisplay, actionRequest, actionResponse, preferences);
        }
        catch (Exception e) {
            if (e instanceof AuthException) {
                Throwable cause = e.getCause();

                if (cause instanceof PasswordExpiredException ||
                    cause instanceof UserLockoutException) {

                    SessionErrors.add(
                        actionRequest, cause.getClass().getName());
                }
                else {
                    SessionErrors.add(actionRequest, e.getClass().getName());
                }
            }
            else if (e instanceof CookieNotSupportedException ||
                     e instanceof NoSuchUserException ||
                     e instanceof PasswordExpiredException ||
                     e instanceof UserEmailAddressException ||
                     e instanceof UserIdException ||
                     e instanceof UserLockoutException ||
                     e instanceof UserPasswordException ||
                     e instanceof UserScreenNameException ||
                     e instanceof CaptchaTextException) {

                SessionErrors.add(actionRequest, e.getClass().getName());
            }
            else {
                PortalUtil.sendError(e, actionRequest, actionResponse);
            }
        }
    }


protected void login(ThemeDisplay themeDisplay, ActionRequest actionRequest, ActionResponse actionResponse, PortletPreferences preferences)
        throws Exception {
	
        HttpServletRequest request = PortalUtil.getHttpServletRequest(actionRequest);
        HttpServletResponse response = PortalUtil.getHttpServletResponse(actionResponse);

        String login = ParamUtil.getString(actionRequest, "login");
        String password = ParamUtil.getString(actionRequest, "password");
        boolean rememberMe = ParamUtil.getBoolean(actionRequest, "rememberMe");

        String authType = preferences.getValue("authType", null);
       
        CaptchaUtil.check(actionRequest);

        LoginUtil.login(request, response, login, password, rememberMe, authType);
        Props PropsValues = PropsUtil.

        if (PropsValues.PORTAL_JAAS_ENABLE) {
            actionResponse.sendRedirect(themeDisplay.getPathMain() + "/portal/protected");
        }
        else {
            String redirect = ParamUtil.getString(actionRequest, "redirect");

            if (Validator.isNotNull(redirect)) {
                redirect = PortalUtil.escapeRedirect(redirect);

                actionResponse.sendRedirect(redirect);
            }
            else {
                actionResponse.sendRedirect(themeDisplay.getPathMain());
            }
        }
    }*/
	
	
	
	


