package com.jio.portlet.mantors.helper;

public interface MentorsPortletConstants {

	public static final String MentorsId="mentorsId";
	public static final String Name="name";
	public static final String Mentor_Images="mentorImage";
	public static final String Mentor_Image_Folder="mentorImages";
	public static final String Company_Name="companyName";
	public static final String Category="category";
	public static final String Short_Description="shortDescription";
	public static final String Long_Description="longDescription";
	public static final String Number="number";
}
