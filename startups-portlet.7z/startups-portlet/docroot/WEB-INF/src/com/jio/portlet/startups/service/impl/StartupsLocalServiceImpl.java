/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.jio.portlet.startups.service.impl;

import com.jio.portlet.startups.model.Startups;
import com.jio.portlet.startups.service.base.StartupsLocalServiceBaseImpl;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQueryFactoryUtil;
import com.liferay.portal.kernel.dao.orm.Junction;
import com.liferay.portal.kernel.dao.orm.Property;
import com.liferay.portal.kernel.dao.orm.PropertyFactoryUtil;
import com.liferay.portal.kernel.dao.orm.RestrictionsFactoryUtil;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;

import java.util.List;

/**
 * The implementation of the startups local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.jio.portlet.startups.service.StartupsLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author rajnikant.donga
 * @see com.jio.portlet.startups.service.base.StartupsLocalServiceBaseImpl
 * @see com.jio.portlet.startups.service.StartupsLocalServiceUtil
 */
public class StartupsLocalServiceImpl extends StartupsLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this interface directly. Always use {@link com.jio.portlet.startups.service.StartupsLocalServiceUtil} to access the startups local service.
	 */
	
	
	@SuppressWarnings("unchecked")
	public List<Startups> getSearchStartups(String name,
			String companyName, boolean andSearch, int start, int end)
			throws SystemException {
		DynamicQuery dynamicQuery = buildStartupsDynamicQuery(name,
				companyName, andSearch);

		return startupsLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	public int getSearchStartupsCount(String name,
			String companyName, boolean andSearch) throws SystemException {
		DynamicQuery dynamicQuery = buildStartupsDynamicQuery(name,
				companyName, andSearch);
		return (int) startupsLocalService.dynamicQueryCount(dynamicQuery);
	}

	protected DynamicQuery buildStartupsDynamicQuery(String name,
			String companyName, boolean andSearch) {

		Junction junction = null;
		if (andSearch) {
			junction = RestrictionsFactoryUtil.conjunction();
		} else {
			junction = RestrictionsFactoryUtil.disjunction();
		}

		if (Validator.isNotNull(name)) {
			Property property = PropertyFactoryUtil.forName("name");
			String value = (new StringBuilder(StringPool.PERCENT))
					.append(name).append(StringPool.PERCENT).toString();
			junction.add(property.like(value));
		}
		if (Validator.isNotNull(companyName)) {
			Property property = PropertyFactoryUtil
					.forName("companyName");
			String value = (new StringBuilder(StringPool.PERCENT))
					.append(companyName).append(StringPool.PERCENT)
					.toString();
			junction.add(property.like(value));
		}
		DynamicQuery dynamicQuery = DynamicQueryFactoryUtil.forClass(
				Startups.class, getClassLoader());
		return dynamicQuery.add(junction);

	}
	
	
}